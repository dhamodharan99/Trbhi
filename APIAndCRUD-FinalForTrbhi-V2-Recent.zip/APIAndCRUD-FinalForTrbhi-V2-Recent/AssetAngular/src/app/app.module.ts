import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { ToastrModule } from 'ngx-toastr'; 

import { AppComponent } from './app.component';
import { AssetDetailsComponent } from './asset-details/asset-details.component';
import { AssetDetailComponent } from './asset-details/asset-detail/asset-detail.component';
import { AssetDetailListComponent } from './asset-details/asset-detail-list/asset-detail-list.component';
import { AssetDetailService } from './shared/asset-detail.service';

@NgModule({
  declarations: [
    AppComponent,
    AssetDetailsComponent,
    AssetDetailComponent,
    AssetDetailListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [AssetDetailService],
  bootstrap: [AppComponent]
})
export class AppModule { }

