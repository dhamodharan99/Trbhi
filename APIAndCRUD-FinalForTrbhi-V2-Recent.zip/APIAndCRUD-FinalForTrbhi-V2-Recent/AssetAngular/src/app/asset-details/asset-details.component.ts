import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-details',
  templateUrl: './asset-details.component.html',
  styles: []
})
export class AssetDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
