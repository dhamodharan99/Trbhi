import { AssetDetail } from './Asset-detail.model';
import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AssetDetailService {
  formData: AssetDetail;
  readonly rootURL = 'http://localhost:55514/api'; //http://localhost:57701/api'; //59035
  list : AssetDetail[];

  constructor(private http: HttpClient) { }

  postAssetDetail() {
    return this.http.post(this.rootURL + '/AssetDetails', this.formData);
  }
  putAssetDetail() {
    return this.http.put(this.rootURL + '/AssetDetails/'+ this.formData.Asset_id, this.formData);
  }
  deleteAssetDetail(Asset_id) {
    return this.http.delete(this.rootURL + '/AssetDetails/'+ Asset_id);
  }

  refreshList(){
    this.http.get(this.rootURL + '/AssetDetails')
    .toPromise()
    .then(
      res => this.list = res as AssetDetail[]);
  }
}
