﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AssetAPI2.Models;

namespace AssetAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetDetailsController : ControllerBase
    {
        private readonly AssetDetailContext _context;

        public AssetDetailsController(AssetDetailContext context)
        {
            _context = context;
        }

        // GET: api/AssetDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AssetDetail>>> GetAssetDetails()
        {
            return await _context.AssetDetails.ToListAsync();
        }

        // GET: api/AssetDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AssetDetail>> GetAssetDetail(int id)
        {
            var assetDetail = await _context.AssetDetails.FindAsync(id);

            if (assetDetail == null)
            {
                return NotFound();
            }

            return assetDetail;
        }

        // PUT: api/AssetDetails/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAssetDetail(int id, AssetDetail assetDetail)
        {
            if (id != assetDetail.Asset_id)
            {
                return BadRequest();
            }

            _context.Entry(assetDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AssetDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AssetDetails
        [HttpPost]
        public async Task<ActionResult<AssetDetail>> PostAssetDetail(AssetDetail assetDetail)
        {
            _context.AssetDetails.Add(assetDetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAssetDetail", new { id = assetDetail.Asset_id }, assetDetail);
        }

        // DELETE: api/AssetDetails/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AssetDetail>> DeleteAssetDetail(int id)
        {
            var assetDetail = await _context.AssetDetails.FindAsync(id);
            if (assetDetail == null)
            {
                return NotFound();
            }

            _context.AssetDetails.Remove(assetDetail);
            await _context.SaveChangesAsync();

            return assetDetail;
        }

        private bool AssetDetailExists(int id)
        {
            return _context.AssetDetails.Any(e => e.Asset_id == id);
        }
    }
}
