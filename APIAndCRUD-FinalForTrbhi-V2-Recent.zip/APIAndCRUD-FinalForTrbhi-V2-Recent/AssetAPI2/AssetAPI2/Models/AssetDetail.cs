﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AssetAPI2.Models
{
    public class AssetDetail
    {
        [Key]
        public int Asset_id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string file_name { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string mime_type { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string email { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string country { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string description { get; set; }
    }
}
